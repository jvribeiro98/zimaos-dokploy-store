ui            = true
disable_mlock = true

api_addr     = "https://localhost"
cluster_addr = "https://openbao:8201"

storage "raft" {
  path    = "/openbao/file"
  node_id = "openbao-1"
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  # TLS is terminated by Traefik (Dokploy)
  tls_disable     = true
}
